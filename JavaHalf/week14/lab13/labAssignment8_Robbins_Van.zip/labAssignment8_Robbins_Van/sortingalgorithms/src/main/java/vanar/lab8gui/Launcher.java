package vanar.lab8gui;

public class Launcher {
    public static void main(final String[] args) {
        App.main(args);
    }
}
