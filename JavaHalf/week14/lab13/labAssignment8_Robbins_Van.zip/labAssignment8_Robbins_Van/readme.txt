jar file requires java 21+
Output graph uses log scale to better visualize differences
Sample output in sample folder
