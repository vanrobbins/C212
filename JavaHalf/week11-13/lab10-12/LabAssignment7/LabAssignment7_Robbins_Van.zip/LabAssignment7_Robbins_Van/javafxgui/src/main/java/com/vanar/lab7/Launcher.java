package com.vanar.lab7;

public class Launcher {
    public static void main(final String[] args) {
        App.main(args);
    }
}
